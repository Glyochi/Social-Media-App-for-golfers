package com.example.roundtrip.Repository;

import com.example.roundtrip.Model.Score;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ScoreRepository extends JpaRepository<Score, Long> {
}
