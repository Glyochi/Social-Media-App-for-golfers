package com.example.roundtrip;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RoundTripApplicationTests {

    @Test
    void contextLoads() {
    }

}
